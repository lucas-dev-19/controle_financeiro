"""
controle_financeiro — app principal Streamlit.
Ponto de entrada: streamlit run app.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import streamlit as st
from database import inicializar_banco
from services.auth import (
    registrar_usuario, login_usuario, logout_usuario,
    usuario_autenticado, usuario_nome_atual, usuario_id_atual
)

# Paginas
from pages import dashboard, transacoes, metas, relatorios

# ── Config ──────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Controle Financeiro",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Inicializa banco na primeira execucao
inicializar_banco()

# ── CSS personalizado ────────────────────────────────────────────────────────
st.markdown("""
<style>
    [data-testid="stSidebar"] { background: #1a1a2e; }
    [data-testid="stSidebar"] * { color: #e0e0e0 !important; }
    .stMetric label { font-size: 0.85rem !important; }
    .stMetric [data-testid="stMetricValue"] { font-size: 1.4rem !important; font-weight: 700; }
    .stButton button { border-radius: 8px !important; }
    div[data-testid="metric-container"] {
        background: #f8f9fa;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        padding: 12px 16px;
    }
</style>
""", unsafe_allow_html=True)


# ── Autenticacao ─────────────────────────────────────────────────────────────
def pagina_login():
    col_l, col_c, col_r = st.columns([1, 2, 1])
    with col_c:
        st.markdown("## Controle Financeiro")
        st.caption("Gerencie suas financas com inteligencia")
        st.divider()
        aba = st.tabs(["Entrar", "Criar Conta"])

        with aba[0]:
            with st.form("login"):
                email = st.text_input("E-mail", placeholder="seu@email.com")
                senha = st.text_input("Senha", type="password")
                if st.form_submit_button("Entrar", use_container_width=True, type="primary"):
                    if email and senha:
                        ok, msg = login_usuario(email, senha)
                        if ok:
                            st.success(msg)
                            st.rerun()
                        else:
                            st.error(msg)
                    else:
                        st.warning("Preencha todos os campos.")

        with aba[1]:
            with st.form("cadastro"):
                nome  = st.text_input("Nome completo")
                email = st.text_input("E-mail")
                senha = st.text_input("Senha (min. 6 caracteres)", type="password")
                conf  = st.text_input("Confirmar senha", type="password")
                if st.form_submit_button("Criar conta", use_container_width=True, type="primary"):
                    if not all([nome, email, senha, conf]):
                        st.warning("Preencha todos os campos.")
                    elif senha != conf:
                        st.error("As senhas nao coincidem.")
                    else:
                        ok, msg = registrar_usuario(nome, email, senha)
                        if ok:
                            st.success(msg + " Faca o login.")
                        else:
                            st.error(msg)


def pagina_app():
    # Sidebar
    with st.sidebar:
        st.markdown("## 💰 Controle Financeiro")
        st.markdown(f"Ola, **{usuario_nome_atual()}**")
        st.divider()

        paginas = {
            "Dashboard":    "📊",
            "Transacoes":   "💳",
            "Metas":        "🎯",
            "Relatorios":   "📄",
        }
        if "pagina_atual" not in st.session_state:
            st.session_state["pagina_atual"] = "Dashboard"

        for p, icone in paginas.items():
            ativo = "primary" if st.session_state["pagina_atual"] == p else "secondary"
            if st.button(f"{icone} {p}", key=f"nav_{p}", use_container_width=True, type=ativo):
                st.session_state["pagina_atual"] = p
                st.rerun()

        st.divider()
        if st.button("Sair", use_container_width=True):
            logout_usuario()
            st.rerun()

    # Roteamento
    pg = st.session_state.get("pagina_atual", "Dashboard")
    if pg == "Dashboard":
        dashboard.render()
    elif pg == "Transacoes":
        transacoes.render()
    elif pg == "Metas":
        metas.render()
    elif pg == "Relatorios":
        relatorios.render()


# ── Entry point ──────────────────────────────────────────────────────────────
if usuario_autenticado():
    pagina_app()
else:
    pagina_login()
