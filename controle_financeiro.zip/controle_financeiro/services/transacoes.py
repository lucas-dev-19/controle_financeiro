"""
Serviço de transações — CRUD + contas + transferências + sumários.
"""

from database import get_connection


# ── transações ────────────────────────────────────────────────────────────────

def listar_transacoes(usuario_id: int, filtros: dict | None = None) -> list[dict]:
    conn = get_connection()
    sql = """
        SELECT t.*, c.nome AS categoria_nome, c.icone AS categoria_icone,
               c.cor AS categoria_cor, ct.nome AS conta_nome
        FROM transacoes t
        LEFT JOIN categorias c  ON c.id  = t.categoria_id
        LEFT JOIN contas     ct ON ct.id = t.conta_id
        WHERE t.usuario_id = ?
    """
    params: list = [usuario_id]
    f = filtros or {}
    if f.get("data_inicio"):  sql += " AND t.data >= ?";          params.append(f["data_inicio"])
    if f.get("data_fim"):     sql += " AND t.data <= ?";          params.append(f["data_fim"])
    if f.get("tipo") and f["tipo"] != "Todos":
        sql += " AND t.tipo = ?";  params.append(f["tipo"].lower())
    if f.get("categoria_id"): sql += " AND t.categoria_id = ?";   params.append(f["categoria_id"])
    if f.get("conta_id"):     sql += " AND t.conta_id = ?";       params.append(f["conta_id"])
    sql += " ORDER BY t.data DESC, t.id DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def adicionar_transacao(usuario_id, conta_id, tipo, valor, descricao, data,
                        categoria_id=None, observacao=None):
    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO transacoes (usuario_id,conta_id,categoria_id,tipo,valor,descricao,data,observacao) VALUES (?,?,?,?,?,?,?,?)",
            (usuario_id, conta_id, categoria_id, tipo, valor, descricao, data, observacao),
        )
        delta = valor if tipo == "receita" else -valor
        conn.execute("UPDATE contas SET saldo=saldo+? WHERE id=? AND usuario_id=?", (delta, conta_id, usuario_id))
        conn.commit()
        return True, "Transação registrada com sucesso!"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def editar_transacao(transacao_id, usuario_id, conta_id, tipo, valor, descricao, data,
                     categoria_id=None, observacao=None):
    conn = get_connection()
    try:
        old = conn.execute("SELECT * FROM transacoes WHERE id=? AND usuario_id=?", (transacao_id, usuario_id)).fetchone()
        if not old: return False, "Transação não encontrada."
        rev = -old["valor"] if old["tipo"] == "receita" else old["valor"]
        conn.execute("UPDATE contas SET saldo=saldo+? WHERE id=? AND usuario_id=?", (rev, old["conta_id"], usuario_id))
        conn.execute(
            "UPDATE transacoes SET conta_id=?,categoria_id=?,tipo=?,valor=?,descricao=?,data=?,observacao=? WHERE id=? AND usuario_id=?",
            (conta_id, categoria_id, tipo, valor, descricao, data, observacao, transacao_id, usuario_id),
        )
        delta = valor if tipo == "receita" else -valor
        conn.execute("UPDATE contas SET saldo=saldo+? WHERE id=? AND usuario_id=?", (delta, conta_id, usuario_id))
        conn.commit()
        return True, "Transação atualizada!"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def excluir_transacao(transacao_id, usuario_id):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM transacoes WHERE id=? AND usuario_id=?", (transacao_id, usuario_id)).fetchone()
        if not row: return False, "Transação não encontrada."
        delta = -row["valor"] if row["tipo"] == "receita" else row["valor"]
        conn.execute("UPDATE contas SET saldo=saldo+? WHERE id=? AND usuario_id=?", (delta, row["conta_id"], usuario_id))
        conn.execute("DELETE FROM transacoes WHERE id=? AND usuario_id=?", (transacao_id, usuario_id))
        conn.commit()
        return True, "Transação excluída."
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


# ── contas ────────────────────────────────────────────────────────────────────

def listar_contas(usuario_id: int) -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM contas WHERE usuario_id=? ORDER BY nome", (usuario_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def adicionar_conta(usuario_id, nome, tipo, saldo, cor):
    conn = get_connection()
    try:
        conn.execute("INSERT INTO contas (usuario_id,nome,tipo,saldo,cor) VALUES (?,?,?,?,?)", (usuario_id, nome, tipo, saldo, cor))
        conn.commit()
        return True, "Conta criada!"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def transferir_entre_contas(usuario_id, origem_id, destino_id, valor, data, descricao=None):
    conn = get_connection()
    try:
        origem = conn.execute("SELECT saldo FROM contas WHERE id=? AND usuario_id=?", (origem_id, usuario_id)).fetchone()
        if not origem or origem["saldo"] < valor:
            return False, "Saldo insuficiente na conta de origem."
        conn.execute("UPDATE contas SET saldo=saldo-? WHERE id=? AND usuario_id=?", (valor, origem_id, usuario_id))
        conn.execute("UPDATE contas SET saldo=saldo+? WHERE id=? AND usuario_id=?", (valor, destino_id, usuario_id))
        conn.execute(
            "INSERT INTO transferencias (usuario_id,conta_origem_id,conta_destino_id,valor,descricao,data) VALUES (?,?,?,?,?,?)",
            (usuario_id, origem_id, destino_id, valor, descricao, data),
        )
        conn.commit()
        return True, "Transferência realizada!"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


# ── categorias ────────────────────────────────────────────────────────────────

def listar_categorias(usuario_id: int, tipo: str | None = None) -> list[dict]:
    conn = get_connection()
    sql, params = "SELECT * FROM categorias WHERE usuario_id=?", [usuario_id]
    if tipo: sql += " AND tipo=?"; params.append(tipo)
    rows = conn.execute(sql + " ORDER BY nome", params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── sumários ──────────────────────────────────────────────────────────────────

def resumo_mes(usuario_id: int, ano: int, mes: int) -> dict:
    conn = get_connection()
    row = conn.execute(
        """SELECT COALESCE(SUM(CASE WHEN tipo='receita' THEN valor ELSE 0 END),0) AS receitas,
                  COALESCE(SUM(CASE WHEN tipo='despesa' THEN valor ELSE 0 END),0) AS despesas
           FROM transacoes WHERE usuario_id=? AND data LIKE ?""",
        (usuario_id, f"{ano:04d}-{mes:02d}%"),
    ).fetchone()
    conn.close()
    r, d = row["receitas"], row["despesas"]
    return {"receitas": r, "despesas": d, "economia": r - d}


def gastos_por_categoria(usuario_id: int, ano: int, mes: int) -> list[dict]:
    conn = get_connection()
    rows = conn.execute(
        """SELECT c.nome, c.cor, c.icone, COALESCE(SUM(t.valor),0) AS total
           FROM categorias c
           LEFT JOIN transacoes t ON t.categoria_id=c.id AND t.tipo='despesa' AND t.data LIKE ?
           WHERE c.usuario_id=? AND c.tipo='despesa'
           GROUP BY c.id ORDER BY total DESC""",
        (f"{ano:04d}-{mes:02d}%", usuario_id),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows if r["total"] > 0]


def evolucao_saldo(usuario_id: int, meses: int = 6) -> list[dict]:
    conn = get_connection()
    rows = conn.execute(
        """SELECT strftime('%Y-%m', data) AS mes,
                  SUM(CASE WHEN tipo='receita' THEN valor ELSE 0 END) AS receitas,
                  SUM(CASE WHEN tipo='despesa' THEN valor ELSE 0 END) AS despesas
           FROM transacoes WHERE usuario_id=?
           GROUP BY mes ORDER BY mes DESC LIMIT ?""",
        (usuario_id, meses),
    ).fetchall()
    conn.close()
    return list(reversed([dict(r) for r in rows]))


def saldo_total(usuario_id: int) -> float:
    conn = get_connection()
    row = conn.execute("SELECT COALESCE(SUM(saldo),0) AS total FROM contas WHERE usuario_id=?", (usuario_id,)).fetchone()
    conn.close()
    return row["total"]
