"""
Serviço de relatórios — PDF com ReportLab + exportação CSV/Excel.
"""

import io
import pandas as pd
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT


def _moeda(v: float) -> str:
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def gerar_pdf(transacoes: list[dict], resumo: dict, mes_ref: str, nome_usuario: str) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    verde  = colors.HexColor("#2E7D32")
    vermelho = colors.HexColor("#C62828")
    azul   = colors.HexColor("#1565C0")
    cinza  = colors.HexColor("#F5F5F5")

    titulo_style = ParagraphStyle("titulo", parent=styles["Title"],
                                  fontSize=18, textColor=verde, alignment=TA_CENTER)
    sub_style    = ParagraphStyle("sub", parent=styles["Normal"],
                                  fontSize=10, textColor=colors.grey, alignment=TA_CENTER)
    secao_style  = ParagraphStyle("secao", parent=styles["Heading2"],
                                  fontSize=13, textColor=azul)

    story = []

    # Cabeçalho
    story.append(Paragraph("💰 Controle Financeiro", titulo_style))
    story.append(Paragraph(f"Relatório de {mes_ref} — {nome_usuario}", sub_style))
    story.append(Paragraph(f"Gerado em {datetime.now().strftime('%d/%m/%Y às %H:%M')}", sub_style))
    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width="100%", thickness=2, color=verde))
    story.append(Spacer(1, 0.5*cm))

    # Cards resumo
    story.append(Paragraph("Resumo do Mês", secao_style))
    resumo_data = [
        ["Receitas", "Despesas", "Economia", "Saldo Total"],
        [
            Paragraph(f'<font color="#2E7D32"><b>{_moeda(resumo["receitas"])}</b></font>', styles["Normal"]),
            Paragraph(f'<font color="#C62828"><b>{_moeda(resumo["despesas"])}</b></font>', styles["Normal"]),
            Paragraph(f'<font color="#1565C0"><b>{_moeda(resumo["economia"])}</b></font>', styles["Normal"]),
            Paragraph(f'<font color="#4527A0"><b>{_moeda(resumo.get("saldo_total", 0))}</b></font>', styles["Normal"]),
        ]
    ]
    t_resumo = Table(resumo_data, colWidths=[4*cm]*4)
    t_resumo.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), verde),
        ("TEXTCOLOR",  (0,0), (-1,0), colors.white),
        ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
        ("ALIGN",      (0,0), (-1,-1), "CENTER"),
        ("GRID",       (0,0), (-1,-1), 0.5, colors.lightgrey),
        ("BACKGROUND", (0,1), (-1,-1), cinza),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [cinza, colors.white]),
        ("FONTSIZE",   (0,0), (-1,-1), 10),
        ("PADDING",    (0,0), (-1,-1), 8),
    ]))
    story.append(t_resumo)
    story.append(Spacer(1, 0.5*cm))

    # Tabela de transações
    story.append(Paragraph("Movimentações", secao_style))
    header = ["Data", "Descrição", "Categoria", "Conta", "Tipo", "Valor"]
    rows = [header]
    for t in transacoes:
        tipo_fmt = "Receita" if t["tipo"] == "receita" else "Despesa"
        valor_str = _moeda(t["valor"])
        rows.append([
            t["data"], t["descricao"][:30],
            t.get("categoria_nome") or "—",
            t.get("conta_nome") or "—",
            tipo_fmt, valor_str,
        ])

    col_w = [2.2*cm, 4.5*cm, 3*cm, 3*cm, 2*cm, 2.5*cm]
    t_trans = Table(rows, colWidths=col_w, repeatRows=1)
    style_list = [
        ("BACKGROUND", (0,0), (-1,0), azul),
        ("TEXTCOLOR",  (0,0), (-1,0), colors.white),
        ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",   (0,0), (-1,-1), 8),
        ("GRID",       (0,0), (-1,-1), 0.4, colors.lightgrey),
        ("ALIGN",      (5,0), (5,-1), "RIGHT"),
        ("PADDING",    (0,0), (-1,-1), 5),
    ]
    for i, row in enumerate(rows[1:], start=1):
        bg = colors.HexColor("#E8F5E9") if row[4] == "Receita" else colors.HexColor("#FFEBEE")
        style_list.append(("BACKGROUND", (0,i), (-1,i), bg))
    t_trans.setStyle(TableStyle(style_list))
    story.append(t_trans)

    doc.build(story)
    return buf.getvalue()


def exportar_csv(transacoes: list[dict]) -> bytes:
    df = _to_dataframe(transacoes)
    return df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")


def exportar_excel(transacoes: list[dict], resumo: dict) -> bytes:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        _to_dataframe(transacoes).to_excel(writer, sheet_name="Movimentações", index=False)
        df_res = pd.DataFrame([{
            "Receitas": resumo["receitas"],
            "Despesas": resumo["despesas"],
            "Economia": resumo["economia"],
        }])
        df_res.to_excel(writer, sheet_name="Resumo", index=False)
    return buf.getvalue()


def _to_dataframe(transacoes: list[dict]) -> pd.DataFrame:
    cols = {
        "data": "Data", "descricao": "Descrição", "tipo": "Tipo",
        "valor": "Valor (R$)", "categoria_nome": "Categoria",
        "conta_nome": "Conta", "observacao": "Observação",
    }
    df = pd.DataFrame(transacoes)
    existing = {k: v for k, v in cols.items() if k in df.columns}
    return df[[*existing]].rename(columns=existing)
