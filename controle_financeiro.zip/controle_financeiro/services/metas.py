"""
Serviço de metas financeiras.
"""

from database import get_connection


def listar_metas(usuario_id: int) -> list[dict]:
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM metas WHERE usuario_id=? ORDER BY concluida, criado_em DESC",
        (usuario_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def adicionar_meta(usuario_id, nome, valor_total, data_limite=None):
    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO metas (usuario_id,nome,valor_total,data_limite) VALUES (?,?,?,?)",
            (usuario_id, nome, valor_total, data_limite),
        )
        conn.commit()
        return True, "Meta criada com sucesso!"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def atualizar_meta(meta_id, usuario_id, nome, valor_total, valor_atual, data_limite=None):
    conn = get_connection()
    try:
        concluida = 1 if valor_atual >= valor_total else 0
        conn.execute(
            "UPDATE metas SET nome=?,valor_total=?,valor_atual=?,data_limite=?,concluida=? WHERE id=? AND usuario_id=?",
            (nome, valor_total, valor_atual, data_limite, concluida, meta_id, usuario_id),
        )
        conn.commit()
        return True, "Meta atualizada!"
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def excluir_meta(meta_id, usuario_id):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM metas WHERE id=? AND usuario_id=?", (meta_id, usuario_id))
        conn.commit()
        return True, "Meta excluída."
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()


def depositar_meta(meta_id, usuario_id, valor):
    conn = get_connection()
    try:
        meta = conn.execute("SELECT * FROM metas WHERE id=? AND usuario_id=?", (meta_id, usuario_id)).fetchone()
        if not meta: return False, "Meta não encontrada."
        novo = min(meta["valor_atual"] + valor, meta["valor_total"])
        concluida = 1 if novo >= meta["valor_total"] else 0
        conn.execute("UPDATE metas SET valor_atual=?, concluida=? WHERE id=? AND usuario_id=?",
                     (novo, concluida, meta_id, usuario_id))
        conn.commit()
        return True, "Valor depositado na meta!" + (" 🎉 Meta concluída!" if concluida else "")
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()
