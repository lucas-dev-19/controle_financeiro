"""
Serviço de autenticação — hash bcrypt, cadastro, login, logout.
"""

import bcrypt
import streamlit as st
from database import get_connection
from models import CATEGORIAS_PADRAO


def _hash(senha: str) -> str:
    return bcrypt.hashpw(senha.encode(), bcrypt.gensalt()).decode()

def _verificar(senha: str, hashed: str) -> bool:
    return bcrypt.checkpw(senha.encode(), hashed.encode())


def registrar_usuario(nome: str, email: str, senha: str):
    if len(senha) < 6:
        return False, "A senha deve ter pelo menos 6 caracteres."
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO usuarios (nome, email, senha) VALUES (?,?,?)",
            (nome.strip(), email.strip().lower(), _hash(senha)),
        )
        uid = cur.lastrowid
        _dados_iniciais(cur, uid)
        conn.commit()
        return True, "Conta criada com sucesso!"
    except Exception as e:
        return (False, "E-mail já cadastrado.") if "UNIQUE" in str(e) else (False, str(e))
    finally:
        conn.close()


def login_usuario(email: str, senha: str):
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM usuarios WHERE email=?", (email.strip().lower(),)
        ).fetchone()
        if not row:
            return False, "E-mail não encontrado."
        if not _verificar(senha, row["senha"]):
            return False, "Senha incorreta."
        st.session_state.update({"usuario_id": row["id"], "usuario_nome": row["nome"], "autenticado": True})
        return True, f"Bem-vindo(a), {row['nome']}!"
    finally:
        conn.close()


def logout_usuario():
    for k in ["usuario_id", "usuario_nome", "autenticado"]:
        st.session_state.pop(k, None)

def usuario_autenticado() -> bool:
    return st.session_state.get("autenticado", False)

def usuario_id_atual():
    return st.session_state.get("usuario_id")

def usuario_nome_atual() -> str:
    return st.session_state.get("usuario_nome", "")


def _dados_iniciais(cur, uid: int):
    for c in CATEGORIAS_PADRAO:
        cur.execute(
            "INSERT INTO categorias (usuario_id, nome, tipo, icone, cor) VALUES (?,?,?,?,?)",
            (uid, c["nome"], c["tipo"], c["icone"], c["cor"]),
        )
    cur.execute(
        "INSERT INTO contas (usuario_id, nome, tipo, saldo, cor) VALUES (?,?,?,?,?)",
        (uid, "Carteira", "Carteira", 0.0, "#4CAF50"),
    )
