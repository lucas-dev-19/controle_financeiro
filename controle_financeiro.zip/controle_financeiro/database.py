"""
Módulo de banco de dados — controle_financeiro
Gerencia a conexão e criação das tabelas SQLite.
"""

import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "database" / "financeiro.db"


def get_connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def inicializar_banco() -> None:
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            nome      TEXT    NOT NULL,
            email     TEXT    NOT NULL UNIQUE,
            senha     TEXT    NOT NULL,
            criado_em TEXT    DEFAULT (datetime('now','localtime'))
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS contas (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            nome       TEXT    NOT NULL,
            tipo       TEXT    NOT NULL DEFAULT 'Carteira',
            saldo      REAL    NOT NULL DEFAULT 0.0,
            cor        TEXT    DEFAULT '#4CAF50',
            criado_em  TEXT    DEFAULT (datetime('now','localtime'))
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS categorias (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            nome       TEXT    NOT NULL,
            tipo       TEXT    NOT NULL DEFAULT 'despesa',
            icone      TEXT    DEFAULT '💰',
            cor        TEXT    DEFAULT '#607D8B'
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS transacoes (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id   INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            conta_id     INTEGER NOT NULL REFERENCES contas(id)   ON DELETE CASCADE,
            categoria_id INTEGER          REFERENCES categorias(id),
            tipo         TEXT    NOT NULL CHECK(tipo IN ('receita','despesa')),
            valor        REAL    NOT NULL CHECK(valor > 0),
            descricao    TEXT    NOT NULL,
            data         TEXT    NOT NULL,
            observacao   TEXT,
            criado_em    TEXT    DEFAULT (datetime('now','localtime'))
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS transferencias (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id       INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            conta_origem_id  INTEGER NOT NULL REFERENCES contas(id)   ON DELETE CASCADE,
            conta_destino_id INTEGER NOT NULL REFERENCES contas(id)   ON DELETE CASCADE,
            valor            REAL    NOT NULL CHECK(valor > 0),
            descricao        TEXT,
            data             TEXT    NOT NULL,
            criado_em        TEXT    DEFAULT (datetime('now','localtime'))
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS metas (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            nome        TEXT    NOT NULL,
            valor_total REAL    NOT NULL CHECK(valor_total > 0),
            valor_atual REAL    NOT NULL DEFAULT 0.0,
            data_limite TEXT,
            concluida   INTEGER NOT NULL DEFAULT 0,
            criado_em   TEXT    DEFAULT (datetime('now','localtime'))
        )
    """)

    conn.commit()
    conn.close()
