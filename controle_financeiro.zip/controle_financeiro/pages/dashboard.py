"""
P�gina: Dashboard — visão geral financeira.
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from datetime import date
from services.transacoes import (
    resumo_mes, gastos_por_categoria, evolucao_saldo, saldo_total, listar_contas
)
from services.auth import usuario_id_atual, usuario_nome_atual


def _moeda(v: float) -> str:
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def render():
    uid = usuario_id_atual()
    hoje = date.today()

    st.markdown(f"## Ola, {usuario_nome_atual()}!")
    st.caption(f"Hoje e dia {hoje.strftime('%d/%m/%Y')}")
    st.divider()

    meses_nomes = ["Janeiro","Fevereiro","Marco","Abril","Maio","Junho",
                   "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"]
    col_m, col_a, _ = st.columns([2, 2, 6])
    with col_m:
        mes = st.selectbox("Mes", range(1,13), index=hoje.month-1,
                           format_func=lambda x: meses_nomes[x-1])
    with col_a:
        ano = st.selectbox("Ano", range(hoje.year-3, hoje.year+1), index=3)

    resumo = resumo_mes(uid, ano, mes)
    saldo  = saldo_total(uid)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Saldo Total",    _moeda(saldo))
    c2.metric("Receitas",       _moeda(resumo["receitas"]))
    c3.metric("Despesas",       _moeda(resumo["despesas"]))
    c4.metric("Economia",       _moeda(resumo["economia"]))
    st.divider()

    col_g1, col_g2 = st.columns(2)

    with col_g1:
        st.subheader("Gastos por Categoria")
        cats = gastos_por_categoria(uid, ano, mes)
        if cats:
            fig = px.pie(cats, values="total", names="nome", hole=0.45,
                         color="nome",
                         color_discrete_map={c["nome"]: c["cor"] for c in cats})
            fig.update_traces(textposition="inside", textinfo="percent+label")
            fig.update_layout(showlegend=False, height=320, margin=dict(t=10,b=10,l=10,r=10))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Nenhum gasto registrado neste mes.")

    with col_g2:
        st.subheader("Receitas vs Despesas (6 meses)")
        ev = evolucao_saldo(uid, 6)
        if ev:
            fig2 = go.Figure()
            lbl = [e["mes"] for e in ev]
            fig2.add_bar(x=lbl, y=[e["receitas"] for e in ev], name="Receitas", marker_color="#4CAF50")
            fig2.add_bar(x=lbl, y=[e["despesas"] for e in ev], name="Despesas", marker_color="#F44336")
            fig2.update_layout(barmode="group", height=320, margin=dict(t=10,b=10,l=10,r=10))
            st.plotly_chart(fig2, use_container_width=True)
        else:
            st.info("Sem dados para o grafico.")

    st.subheader("Evolucao do Saldo Acumulado")
    ev12 = evolucao_saldo(uid, 12)
    if ev12:
        acum, acc = [], 0.0
        for e in ev12:
            acc += e["receitas"] - e["despesas"]
            acum.append({"mes": e["mes"], "saldo": acc})
        fig3 = px.area(acum, x="mes", y="saldo", color_discrete_sequence=["#1976D2"])
        fig3.update_layout(height=260, margin=dict(t=10,b=10,l=10,r=10))
        st.plotly_chart(fig3, use_container_width=True)

    st.subheader("Suas Contas")
    contas = listar_contas(uid)
    if contas:
        cols = st.columns(min(len(contas), 4))
        for i, c in enumerate(contas):
            with cols[i % 4]:
                st.markdown(
                    f"""<div style='background:{c["cor"]}22;border-left:4px solid {c["cor"]};
                    padding:12px;border-radius:8px;margin-bottom:8px'>
                    <b>{c["nome"]}</b><br><small>{c["tipo"]}</small><br>
                    <span style='font-size:1.2em;font-weight:700'>{_moeda(c["saldo"])}</span>
                    </div>""",
                    unsafe_allow_html=True,
                )
    else:
        st.info("Nenhuma conta cadastrada.")
