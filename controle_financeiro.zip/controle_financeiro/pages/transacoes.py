"""
Pagina: Transacoes — cadastro, edicao, exclusao e historico.
"""

import streamlit as st
import pandas as pd
from datetime import date
from services.transacoes import (
    listar_transacoes, adicionar_transacao, editar_transacao,
    excluir_transacao, listar_categorias, listar_contas,
    adicionar_conta, transferir_entre_contas
)
from services.auth import usuario_id_atual
from models import TIPOS_CONTA


def _moeda(v: float) -> str:
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def render():
    uid = usuario_id_atual()
    aba = st.tabs(["Nova Transacao", "Historico", "Contas & Transferencias"])

    # ── Aba 1: Nova transacao ─────────────────────────────────────────────
    with aba[0]:
        st.subheader("Registrar Lancamento")
        tipo = st.radio("Tipo", ["Receita", "Despesa"], horizontal=True)
        tipo_db = tipo.lower()

        contas = listar_contas(uid)
        cats   = listar_categorias(uid, tipo_db)

        if not contas:
            st.warning("Crie uma conta antes de registrar transacoes.")
            return

        with st.form("form_transacao", clear_on_submit=True):
            descricao    = st.text_input("Descricao *")
            valor        = st.number_input("Valor (R$) *", min_value=0.01, step=0.01, format="%.2f")
            data_t       = st.date_input("Data *", value=date.today())
            conta_id     = st.selectbox("Conta *", contas, format_func=lambda c: c["nome"])
            categoria_id = st.selectbox("Categoria", cats, format_func=lambda c: f"{c['icone']} {c['nome']}")
            observacao   = st.text_area("Observacao (opcional)", height=80)
            submitted    = st.form_submit_button("Salvar", use_container_width=True, type="primary")

            if submitted:
                if not descricao.strip():
                    st.error("Descricao obrigatoria.")
                else:
                    ok, msg = adicionar_transacao(
                        uid, conta_id["id"], tipo_db, valor,
                        descricao.strip(), str(data_t),
                        categoria_id["id"] if categoria_id else None,
                        observacao.strip() or None,
                    )
                    (st.success if ok else st.error)(msg)

    # ── Aba 2: Historico ──────────────────────────────────────────────────
    with aba[1]:
        st.subheader("Historico de Movimentacoes")

        contas = listar_contas(uid)
        cats_all = listar_categorias(uid)

        with st.expander("Filtros", expanded=True):
            fc1, fc2, fc3 = st.columns(3)
            with fc1:
                tipo_filtro = st.selectbox("Tipo", ["Todos", "Receita", "Despesa"])
            with fc2:
                cat_opts = [{"id": None, "nome": "Todas", "icone": ""}] + cats_all
                cat_sel  = st.selectbox("Categoria", cat_opts,
                                        format_func=lambda c: f"{c['icone']} {c['nome']}".strip())
            with fc3:
                conta_opts = [{"id": None, "nome": "Todas"}] + contas
                conta_sel  = st.selectbox("Conta", conta_opts, format_func=lambda c: c["nome"])
            fd1, fd2 = st.columns(2)
            with fd1:
                data_ini = st.date_input("De", value=None)
            with fd2:
                data_fim = st.date_input("Ate", value=None)

        filtros = {
            "tipo":         tipo_filtro,
            "categoria_id": cat_sel["id"],
            "conta_id":     conta_sel["id"],
            "data_inicio":  str(data_ini) if data_ini else None,
            "data_fim":     str(data_fim) if data_fim else None,
        }
        transacoes = listar_transacoes(uid, filtros)

        if not transacoes:
            st.info("Nenhuma transacao encontrada.")
            return

        total_rec = sum(t["valor"] for t in transacoes if t["tipo"] == "receita")
        total_dep = sum(t["valor"] for t in transacoes if t["tipo"] == "despesa")
        m1, m2, m3 = st.columns(3)
        m1.metric("Receitas filtradas",  _moeda(total_rec))
        m2.metric("Despesas filtradas",  _moeda(total_dep))
        m3.metric("Saldo filtrado",      _moeda(total_rec - total_dep))

        st.divider()

        for t in transacoes:
            cor   = "#4CAF50" if t["tipo"] == "receita" else "#F44336"
            sinal = "+" if t["tipo"] == "receita" else "-"
            icone = t.get("categoria_icone") or ("📈" if t["tipo"] == "receita" else "📉")
            with st.container():
                col_info, col_val, col_acao = st.columns([5, 2, 1])
                with col_info:
                    st.markdown(
                        f"{icone} **{t['descricao']}**  "
                        f"<small style='color:grey'>{t['data']} · {t.get('conta_nome','—')} · "
                        f"{t.get('categoria_nome','—')}</small>",
                        unsafe_allow_html=True,
                    )
                with col_val:
                    st.markdown(
                        f"<span style='color:{cor};font-weight:700;font-size:1.1em'>"
                        f"{sinal}{_moeda(t['valor'])}</span>",
                        unsafe_allow_html=True,
                    )
                with col_acao:
                    if st.button("🗑️", key=f"del_{t['id']}", help="Excluir"):
                        ok, msg = excluir_transacao(t["id"], uid)
                        (st.success if ok else st.error)(msg)
                        st.rerun()
            st.divider()

    # ── Aba 3: Contas & Transferencias ────────────────────────────────────
    with aba[2]:
        col_nova, col_transf = st.columns(2)

        with col_nova:
            st.subheader("Nova Conta")
            with st.form("form_conta", clear_on_submit=True):
                nome_c  = st.text_input("Nome da conta *")
                tipo_c  = st.selectbox("Tipo", TIPOS_CONTA)
                saldo_c = st.number_input("Saldo inicial (R$)", min_value=0.0, step=0.01, format="%.2f")
                cor_c   = st.color_picker("Cor", "#4CAF50")
                if st.form_submit_button("Criar conta", use_container_width=True):
                    if nome_c.strip():
                        ok, msg = adicionar_conta(uid, nome_c.strip(), tipo_c, saldo_c, cor_c)
                        (st.success if ok else st.error)(msg)
                    else:
                        st.error("Nome obrigatorio.")

        with col_transf:
            st.subheader("Transferencia entre Contas")
            contas = listar_contas(uid)
            if len(contas) < 2:
                st.info("Voce precisa de pelo menos 2 contas para transferir.")
            else:
                with st.form("form_transf", clear_on_submit=True):
                    origem  = st.selectbox("De", contas, format_func=lambda c: f"{c['nome']} ({_moeda(c['saldo'])})")
                    destino = st.selectbox("Para", contas, format_func=lambda c: f"{c['nome']} ({_moeda(c['saldo'])})")
                    val_t   = st.number_input("Valor (R$)", min_value=0.01, step=0.01, format="%.2f")
                    data_tr = st.date_input("Data", value=date.today())
                    desc_tr = st.text_input("Descricao (opcional)")
                    if st.form_submit_button("Transferir", use_container_width=True):
                        if origem["id"] == destino["id"]:
                            st.error("Contas de origem e destino devem ser diferentes.")
                        else:
                            ok, msg = transferir_entre_contas(
                                uid, origem["id"], destino["id"], val_t, str(data_tr), desc_tr or None
                            )
                            (st.success if ok else st.error)(msg)
                            if ok: st.rerun()

        st.subheader("Suas Contas")
        contas = listar_contas(uid)
        for c in contas:
            st.markdown(
                f"<div style='background:{c['cor']}18;border-left:4px solid {c['cor']};"
                f"padding:10px;border-radius:6px;margin-bottom:6px'>"
                f"<b>{c['nome']}</b> <small>({c['tipo']})</small> — "
                f"<b>{_moeda(c['saldo'])}</b></div>",
                unsafe_allow_html=True,
            )
