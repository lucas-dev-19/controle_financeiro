"""
Pagina: Relatorios — exportacao PDF, CSV, Excel e IA financeira.
"""

import streamlit as st
import json
import requests
from datetime import date
from services.transacoes import listar_transacoes, resumo_mes, saldo_total
from services.relatorios import gerar_pdf, exportar_csv, exportar_excel
from services.auth import usuario_id_atual, usuario_nome_atual


def _moeda(v: float) -> str:
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _contexto_financeiro(uid: int, mes: int, ano: int) -> str:
    """Monta contexto financeiro para a IA."""
    from services.transacoes import gastos_por_categoria, evolucao_saldo, listar_contas
    resumo   = resumo_mes(uid, ano, mes)
    cats     = gastos_por_categoria(uid, ano, mes)
    ev       = evolucao_saldo(uid, 6)
    contas   = listar_contas(uid)
    saldo    = saldo_total(uid)

    mes_ant = (mes - 2) % 12 + 1
    ano_ant = ano if mes > 1 else ano - 1
    resumo_ant = resumo_mes(uid, ano_ant, mes_ant)

    cats_str = ", ".join(f"{c['nome']}: {_moeda(c['total'])}" for c in cats[:5]) or "Nenhum"
    ev_str   = " | ".join(f"{e['mes']}: rec={_moeda(e['receitas'])} dep={_moeda(e['despesas'])}" for e in ev[-3:])

    return f"""
Dados financeiros do usuario:
- Saldo total nas contas: {_moeda(saldo)}
- Mes atual ({ano}-{mes:02d}): Receitas={_moeda(resumo['receitas'])}, Despesas={_moeda(resumo['despesas'])}, Economia={_moeda(resumo['economia'])}
- Mes anterior ({ano_ant}-{mes_ant:02d}): Receitas={_moeda(resumo_ant['receitas'])}, Despesas={_moeda(resumo_ant['despesas'])}
- Principais gastos por categoria: {cats_str}
- Evolucao recente: {ev_str}
- Numero de contas: {len(contas)}
"""


def _ia_resposta(contexto: str, pergunta: str) -> str:
    """Chama a API da Anthropic internamente."""
    try:
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"Content-Type": "application/json"},
            json={
                "model": "claude-sonnet-4-6",
                "max_tokens": 1000,
                "system": (
                    "Voce e um consultor financeiro pessoal chamado FinBot. "
                    "Responda SEMPRE em portugues do Brasil, de forma direta, objetiva e amigavel. "
                    "Use os dados financeiros fornecidos para dar insights precisos. "
                    "Quando mencionar valores, use o formato R$ x.xxx,xx. "
                    "Seja encorajador mas honesto."
                ),
                "messages": [
                    {"role": "user", "content": f"{contexto}\n\nPergunta do usuario: {pergunta}"}
                ],
            },
            timeout=30,
        )
        data = resp.json()
        if "content" in data:
            return data["content"][0]["text"]
        return "Nao foi possivel obter resposta da IA no momento."
    except Exception as e:
        return f"Erro ao conectar com a IA: {e}"


def render():
    uid  = usuario_id_atual()
    nome = usuario_nome_atual()
    hoje = date.today()

    aba = st.tabs(["Exportar Relatorio", "IA Financeira"])

    # ── Aba 1: Exportacao ─────────────────────────────────────────────────
    with aba[0]:
        st.subheader("Gerar e Exportar Relatorio")
        meses_nomes = ["Janeiro","Fevereiro","Marco","Abril","Maio","Junho",
                       "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"]
        c1, c2 = st.columns(2)
        with c1:
            mes = st.selectbox("Mes", range(1,13), index=hoje.month-1,
                               format_func=lambda x: meses_nomes[x-1])
        with c2:
            ano = st.selectbox("Ano", range(hoje.year-3, hoje.year+1), index=3)

        filtros = {
            "data_inicio": f"{ano:04d}-{mes:02d}-01",
            "data_fim":    f"{ano:04d}-{mes:02d}-31",
        }
        transacoes = listar_transacoes(uid, filtros)
        resumo     = resumo_mes(uid, ano, mes)
        resumo["saldo_total"] = saldo_total(uid)
        mes_ref    = f"{meses_nomes[mes-1]} {ano}"

        m1, m2, m3 = st.columns(3)
        m1.metric("Receitas",  _moeda(resumo["receitas"]))
        m2.metric("Despesas",  _moeda(resumo["despesas"]))
        m3.metric("Economia",  _moeda(resumo["economia"]))

        st.divider()
        st.caption(f"{len(transacoes)} transacoes encontradas para {mes_ref}")

        btn1, btn2, btn3 = st.columns(3)
        with btn1:
            pdf_bytes = gerar_pdf(transacoes, resumo, mes_ref, nome)
            st.download_button(
                "Baixar PDF", pdf_bytes,
                file_name=f"relatorio_{ano}_{mes:02d}.pdf",
                mime="application/pdf", use_container_width=True,
            )
        with btn2:
            if transacoes:
                st.download_button(
                    "Baixar CSV", exportar_csv(transacoes),
                    file_name=f"relatorio_{ano}_{mes:02d}.csv",
                    mime="text/csv", use_container_width=True,
                )
        with btn3:
            if transacoes:
                st.download_button(
                    "Baixar Excel", exportar_excel(transacoes, resumo),
                    file_name=f"relatorio_{ano}_{mes:02d}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )

    # ── Aba 2: IA Financeira ──────────────────────────────────────────────
    with aba[1]:
        st.subheader("IA Financeira — FinBot")
        st.caption("Faca perguntas sobre suas financas e receba analises personalizadas.")

        sugestoes = [
            "Gastei muito esse mes?",
            "Em qual categoria estou gastando mais?",
            "Como esta minha economia comparada ao mes passado?",
            "Minha saude financeira esta boa?",
            "Quais habitos devo mudar para economizar mais?",
        ]
        cols = st.columns(len(sugestoes))
        pergunta_sugerida = None
        for i, s in enumerate(sugestoes):
            with cols[i]:
                if st.button(s, key=f"sug_{i}", use_container_width=True):
                    pergunta_sugerida = s

        pergunta = st.text_area(
            "Sua pergunta:",
            value=pergunta_sugerida or "",
            placeholder="Ex: Gastei muito esse mes? / Onde posso economizar?",
            height=100,
        )

        if st.button("Perguntar para a IA", type="primary", use_container_width=True):
            if not pergunta.strip():
                st.warning("Digite uma pergunta.")
            else:
                with st.spinner("FinBot esta analisando suas financas..."):
                    mes_ia = hoje.month
                    ano_ia = hoje.year
                    contexto = _contexto_financeiro(uid, mes_ia, ano_ia)
                    resposta = _ia_resposta(contexto, pergunta)

                st.markdown("---")
                st.markdown("#### Resposta do FinBot")
                st.markdown(
                    f"<div style='background:#E8F5E9;border-left:4px solid #4CAF50;"
                    f"padding:16px;border-radius:8px'>{resposta}</div>",
                    unsafe_allow_html=True,
                )

        # Insights automaticos
        st.divider()
        st.subheader("Insights Automaticos")
        if st.button("Gerar Insights do Mes Atual"):
            with st.spinner("Analisando seus dados..."):
                contexto = _contexto_financeiro(uid, hoje.month, hoje.year)
                insights = _ia_resposta(
                    contexto,
                    "Analise minha situacao financeira deste mes e gere 3 a 5 insights "
                    "objetivos, com alertas e oportunidades de melhoria. Use bullet points."
                )
            st.markdown(
                f"<div style='background:#E3F2FD;border-left:4px solid #1976D2;"
                f"padding:16px;border-radius:8px'>{insights}</div>",
                unsafe_allow_html=True,
            )
