"""
Pagina: Metas Financeiras.
"""

import streamlit as st
from services.metas import listar_metas, adicionar_meta, depositar_meta, excluir_meta
from services.auth import usuario_id_atual
from datetime import date


def _moeda(v: float) -> str:
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def render():
    uid = usuario_id_atual()
    aba = st.tabs(["Minhas Metas", "Nova Meta"])

    with aba[0]:
        metas = listar_metas(uid)
        if not metas:
            st.info("Nenhuma meta criada. Crie sua primeira meta na aba ao lado!")
        else:
            for m in metas:
                prog = min(100.0, (m["valor_atual"] / m["valor_total"]) * 100) if m["valor_total"] > 0 else 0
                restante = max(0.0, m["valor_total"] - m["valor_atual"])
                cor = "#4CAF50" if m["concluida"] else ("#FF9800" if prog > 50 else "#2196F3")
                status = "Concluida" if m["concluida"] else f"{prog:.1f}% concluido"

                with st.container():
                    st.markdown(
                        f"""<div style='border:1px solid {cor};border-radius:10px;padding:16px;margin-bottom:12px'>
                        <div style='display:flex;justify-content:space-between'>
                        <h4 style='margin:0;color:{cor}'>{m['nome']}</h4>
                        <span style='color:grey;font-size:0.85em'>{status}</span>
                        </div>
                        <div style='margin:8px 0 4px 0;font-size:0.9em'>
                        Economizado: <b>{_moeda(m['valor_atual'])}</b> de
                        <b>{_moeda(m['valor_total'])}</b>
                        — Faltam: <b>{_moeda(restante)}</b>
                        {"   Prazo: " + m['data_limite'] if m['data_limite'] else ""}
                        </div></div>""",
                        unsafe_allow_html=True,
                    )
                    st.progress(prog / 100)

                    if not m["concluida"]:
                        with st.expander("Depositar valor"):
                            with st.form(f"dep_{m['id']}"):
                                val_dep = st.number_input("Valor (R$)", min_value=0.01, step=0.01,
                                                          format="%.2f", key=f"vdep_{m['id']}")
                                if st.form_submit_button("Depositar"):
                                    ok, msg = depositar_meta(m["id"], uid, val_dep)
                                    (st.success if ok else st.error)(msg)
                                    if ok: st.rerun()

                    if st.button("Excluir meta", key=f"exm_{m['id']}", type="secondary"):
                        ok, msg = excluir_meta(m["id"], uid)
                        (st.success if ok else st.error)(msg)
                        if ok: st.rerun()
                st.divider()

    with aba[1]:
        st.subheader("Criar Nova Meta")
        with st.form("form_meta", clear_on_submit=True):
            nome_m   = st.text_input("Nome da meta *", placeholder="Ex: Notebook, Viagem, Reserva...")
            val_tot  = st.number_input("Valor total (R$) *", min_value=1.0, step=50.0, format="%.2f")
            val_ini  = st.number_input("Ja tenho (R$)", min_value=0.0, step=10.0, format="%.2f")
            prazo    = st.date_input("Prazo (opcional)", value=None)
            if st.form_submit_button("Criar Meta", use_container_width=True, type="primary"):
                if not nome_m.strip():
                    st.error("Nome obrigatorio.")
                elif val_ini > val_tot:
                    st.error("O valor ja economizado nao pode ser maior que o total.")
                else:
                    ok, msg = adicionar_meta(uid, nome_m.strip(), val_tot, str(prazo) if prazo else None)
                    if ok and val_ini > 0:
                        metas_novas = listar_metas(uid)
                        if metas_novas:
                            depositar_meta(metas_novas[0]["id"], uid, val_ini)
                    (st.success if ok else st.error)(msg)
                    if ok: st.rerun()
