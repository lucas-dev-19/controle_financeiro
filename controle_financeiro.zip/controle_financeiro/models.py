"""
Modelos de dados — controle_financeiro
"""

from dataclasses import dataclass
from typing import Optional

@dataclass
class Usuario:
    id: int; nome: str; email: str; senha: str; criado_em: str = ""

@dataclass
class Conta:
    id: int; usuario_id: int; nome: str; tipo: str; saldo: float
    cor: str = "#4CAF50"; criado_em: str = ""

@dataclass
class Categoria:
    id: int; usuario_id: int; nome: str; tipo: str
    icone: str = "💰"; cor: str = "#607D8B"

@dataclass
class Transacao:
    id: int; usuario_id: int; conta_id: int; tipo: str; valor: float
    descricao: str; data: str; categoria_id: Optional[int] = None
    observacao: Optional[str] = None; criado_em: str = ""

@dataclass
class Meta:
    id: int; usuario_id: int; nome: str; valor_total: float
    valor_atual: float = 0.0; data_limite: Optional[str] = None
    concluida: bool = False; criado_em: str = ""

    @property
    def progresso(self) -> float:
        return min(100.0, (self.valor_atual / self.valor_total) * 100) if self.valor_total > 0 else 0.0

    @property
    def valor_restante(self) -> float:
        return max(0.0, self.valor_total - self.valor_atual)


CATEGORIAS_PADRAO = [
    {"nome": "Alimentação",   "tipo": "despesa", "icone": "🍽️",  "cor": "#FF5722"},
    {"nome": "Transporte",    "tipo": "despesa", "icone": "🚗",  "cor": "#FF9800"},
    {"nome": "Moradia",       "tipo": "despesa", "icone": "🏠",  "cor": "#9C27B0"},
    {"nome": "Lazer",         "tipo": "despesa", "icone": "🎮",  "cor": "#2196F3"},
    {"nome": "Educação",      "tipo": "despesa", "icone": "📚",  "cor": "#00BCD4"},
    {"nome": "Saúde",         "tipo": "despesa", "icone": "❤️",  "cor": "#F44336"},
    {"nome": "Outros",        "tipo": "despesa", "icone": "📦",  "cor": "#607D8B"},
    {"nome": "Salário",       "tipo": "receita", "icone": "💼",  "cor": "#4CAF50"},
    {"nome": "Freelance",     "tipo": "receita", "icone": "💻",  "cor": "#8BC34A"},
    {"nome": "Investimentos", "tipo": "receita", "icone": "📈",  "cor": "#CDDC39"},
    {"nome": "Outros",        "tipo": "receita", "icone": "💰",  "cor": "#FFC107"},
]

TIPOS_CONTA = ["Carteira", "Conta Corrente", "Poupança", "Investimento", "Outro"]
